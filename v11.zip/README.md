**INSTALLATION**
- Download a JDK with a javac compilier
- (At least version 8 but 17 is recommended)
- Then get VSCode
- Install the Code Runner Extension on VSCode Marketplace
- Then also get Better Comments
- Optionally, Install the Splatoon font (Splatoon2.ttf)
- Compile and run Game.java, the main class

:)